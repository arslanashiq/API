const { Recomended } = require("../models/recomended");
const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

router.get(`/`, async (req, res) => {
  const recomendedList = await Recomended.find();

  if (!recomendedList) {
    res.status(500).json({ success: false });
  }
  res.send({recomendedList,status:200});
});

router.post(`/`, async (req, res) => {
  let recomended = new Recomended({
    name: req.body.name,
    price: req.body.price,
    size:req.body.size,
    image: req.body.image,
    info: req.body.info,
    category:req.body.category,
    
  });
  recomended = await recomended.save();

  if (!recomended) {
    return res.status(500).send("The User cannot be created");
  }

  res.send({recomended,status:200});
});



module.exports = router;
