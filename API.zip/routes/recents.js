const { Recent } = require("../models/recent");
const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

router.get(`/`, async (req, res) => {
  const recentList = await Recent.find();

  if (!recentList) {
    res.status(500).json({ success: false });
  }
  res.send({recentList,status:200});
});

router.post(`/`, async (req, res) => {
  let recent = new Recent({
    name: req.body.name,
    price: req.body.price,
    size:req.body.size,
    image: req.body.image,
    info: req.body.info,
    category:req.body.category,
    
  });
  recent = await recent.save();

  if (!recent) {
    return res.status(500).send("The User cannot be created");
  }

  res.send({recent,status:200});
});



module.exports = router;
