const { Order } = require("../models/order");
const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

router.get(`/`, async (req, res) => {
  const orderlist = await Order.find();

  if (!orderlist) {
    res.status(500).json({ status: false });
  }
  res.send({ orderlist, status: 200 });
});

router.post(`/`, async (req, res) => {
  let order = new Order({
    user_id: req.body.user_id,
    user_detail: req.body.user_detail,
    order_detail: req.body.order_detail,
    total_price: req.body.total_price,
    order_time: req.body.order_time,
    status: req.body.status,
  });
  order = await order.save();

  if (!order) {
    return res.status(500).send("The Order cannot be created");
  }

  res.send({order,status:200});
});

module.exports = router;
