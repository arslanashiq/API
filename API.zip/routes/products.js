const { Product } = require("../models/product");
const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");



router.get(`/`, async (req, res) => {
  const productlist = await Product.find();

  if (!productlist) {
    res.status(500).json({ success: false });
  }
  res.send({productlist,status:200});
});

router.post(`/`, async (req, res) => {

  let product = new Product({
    name: req.body.name,
    price: req.body.price,
    size:req.body.size,
    image: req.body.image,
    category:req.body.category,
    info: req.body.info,
  });

  product = await product.save();

  if (!product) {
    return res.status(500).send("The product cannot be created");
  }

  res.send(product);
});


module.exports = router;
